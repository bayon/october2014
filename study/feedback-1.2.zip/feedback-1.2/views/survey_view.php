<!DOCTYPE html> 
<?php 
    include_once('../config.php'); 
    // SURVEY VIEW
 ?>

<?php   include_once('../models/questions_model.php');   
    //$a_questions = get_questions();
    $test = test(); //THIS WORKS , but not the get_questions function ...??
?>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<title>Mobile Web Apps</title> 
	<link rel="stylesheet"  href="../css/themes/default/jquery.mobile-1.1.1.css" />  
 	<link rel="stylesheet" href="../css/themes/solo/solo.css"/>
	<script src="../js/jquery.js"></script>
 	<script src="../js/solo/solo.js"></script>
	<script src="../js/jquery.mobile-1.1.1.js"></script>
</head> 
<body> 
	<div data-role="page" class="type-interior">
		<div data-role="header" data-theme="<?=$mainTheme;?>" data-position="fixed" data-id="foo">
		<h1><?=$appName;?></h1>
		<a href="../" data-icon="home" data-iconpos="notext" data-direction="reverse">Home</a>
	</div>
	<div data-role="content" data-theme="b" >
 			<form action="../controllers/survey_controller.php" method="post" data-ajax="false" data-theme="b" class="ui-body ui-body-a ui-corner-all">
				<fieldset data-theme="b" >
					<div data-role="fieldcontain">
                        <label for="question1"><?=$a_questions[0]['question_text'];?></label>
                        <select name="question1" id="question1" data-role="slider" data-mini="false">
                        <option value="no">No</option>
                        <option value="yes">Yes</option>
                        </select>
					</div>
					<div data-role="fieldcontain">
			         	<label for="question2"><?=$a_questions[1]['question_text'];?></label>
			         	
                        <fieldset data-role="controlgroup" data-mini="false" data-type="horizontal" >
                        <input type="radio" name="question2" id="radio-mini-1" value="yes" checked="checked" />
                        <label for="radio-mini-1">Yes</label>

                        <input type="radio" name="question2" id="radio-mini-2" value="sort of"  />
                        <label for="radio-mini-2">Sort of</label>

                        <input type="radio" name="question2" id="radio-mini-3" value="no"  />
                        <label for="radio-mini-3">No</label>
                        </fieldset>
					</div>
                    <div data-role="fieldcontain">
                        <label for="question3"><?=$a_questions[2]['question_text'];?></label>
                        
                        <fieldset data-role="controlgroup" data-mini="false" data-type="horizontal" >
                        <input type="radio" name="question3" id="radio-mini-3" value="yes" checked="checked" />
                        <label for="radio-mini-3">Yes</label>

                        <input type="radio" name="question3" id="radio-mini-4" value="sort of"  />
                        <label for="radio-mini-4">Sort of</label>

                        <input type="radio" name="question3" id="radio-mini-5" value="no"  />
                        <label for="radio-mini-5">No</label>
                        </fieldset>
                    </div>
					<div data-role="fieldcontain">
						<label for="question4"><?=$a_questions[3]['question_text'];?></label>
					 	<input type="range" name="question4" id="question4" value="50" min="0" max="100" data-highlight="true"  />
					</div>
					<button type="submit" data-theme="b" name="submit" value="submit-value">Submit</button>
				</fieldset>
			</form>
		</div><!-- /content -->
		<div data-role="footer" data-id="foo1" data-position="fixed">
			<div data-role="navbar">
				<ul>
					<li><a href="survey_view.php" data-prefetch="true" class="ui-btn-active ui-state-persist">Survey</a></li>
					<li><a href="details_view.php" data-prefetch="true">Details</a></li>
					<li><a href="graph_view.php" data-prefetch="true">Graph</a></li>
				</ul>
			</div><!-- /navbar -->
		</div><!-- /footer -->
		</div><!-- /page -->
		</body>
		</html>