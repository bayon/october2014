
<?php 
    
    include_once('../config.php'); 
    // ADMIN VIEW
    include_once('../models/questions_model.php');   
    
    ?>

<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<title>Mobile Web Apps</title> 

<link rel="stylesheet"  href="../css/themes/default/jquery.mobile-1.1.1.css" />  
<link rel="stylesheet" href="../css/themes/solo/solo.css"/>
<script src="../js/jquery.js"></script>
<script src="../js/solo/solo.js"></script>
<script src="../js/jquery.mobile-1.1.1.js"></script>

</head> 
<body> 
	<div data-role="page" class="type-interior">

<div data-role="header" data-theme="<?=$mainTheme;?>" data-position="fixed" data-id="foo">
<h1><?=$appName;?></h1>
<a href="../" data-icon="home" data-iconpos="notext" data-direction="reverse">Home</a>
</div>

	
    <div data-role="content">

        <form action="../controllers/admin_controller.php" method="post" data-ajax="false" class="ui-body ui-body-a ui-corner-all">
            <fieldset>

            <div data-role="fieldcontain">
                <label for="question1">Question 1:</label>
                <input type="text" name="question1" id="question1" value="<?=$a_questions[0]['question_text'];?>"  />
            </div>
            <div data-role="fieldcontain">
                <label for="question2">Question 2:</label>
                <input type="text" name="question2" id="question2" value="<?=$a_questions[1]['question_text'];?>"  />
            </div>
            <div data-role="fieldcontain">
                <label for="question3">Question 3:</label>
                <input type="text" name="question3" id="question3" value="<?=$a_questions[2]['question_text'];?>"  />
            </div>
            <div data-role="fieldcontain">
                <label for="question4">Question 4:</label>
                <input type="text" name="question4" id="question4" value="<?=$a_questions[3]['question_text'];?>"  />
            </div>
            <div data-role="fieldcontain">
                <button type="submit"  name="submit" value="submit-value">Submit</button>
            </div>

            </fieldset>
        </form>


    </div><!-- /content -->

		<div data-role="footer" data-id="foo1" data-position="fixed">
			<div data-role="navbar">
				<ul>
                    <li><a href="survey_view.php" data-prefetch="true" >Survey</a></li>
                    <li><a href="details_view.php" data-prefetch="true">Details</a></li>

                    <li><a href="graph_view.php" data-prefetch="true">Graph</a></li>

                     <li><a href="admin_view.php" data-prefetch="true"  class="ui-btn-active ui-state-persist"   >Admin</a></li>
				</ul>
			</div><!-- /navbar -->
		</div><!-- /footer -->

		</div><!-- /page -->

		</body>
		</html>