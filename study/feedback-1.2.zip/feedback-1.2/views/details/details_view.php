<!DOCTYPE html> 
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<title>Mobile Web Apps</title> 

	<link rel="stylesheet"  href="../css/themes/default/jquery.mobile-1.1.1.css" />  
 	<link rel="stylesheet" href="../css/themes/solo/solo.css"/>
	<script src="../js/jquery.js"></script>
 	<script src="../js/solo/solo.js"></script>
	<script src="../js/jquery.mobile-1.1.1.js"></script>

</head> 

<?php   include('../models/questions_model.php');   ?>

<body> 

	<div data-role="dialog" data-rel="back" class="type-interior"  >

		<div data-role="header" data-theme="<?=$mainTheme;?>" data-position="fixed" data-id="foo">
		<h1>Details for: <?=$data[0]['username'];?></h1>
		<a href="../" data-icon="home" data-iconpos="notext" data-direction="reverse">Home</a>
		 
	</div>
	<script>
		$('.ui-icon-delete').css('display','none');
		
	</script>
	<div data-role="content" style="min-height:100px;background-color:#ffffff;">
		 <?php
		 //echo('<pre>');
		 //print_r($data);
		 //echo('</pre>');
		 
		  ?>
		 <div data-role="fieldcontain">
		    <label for="q1"><?=$a_questions[0]['question_text'];?>:</label>
		    <input type="text" name="q1" id="q1" value="<?=$data[0]['answer_1'];?>"  />
		</div>
        <div data-role="fieldcontain">
        <label for="q2"><?=$a_questions[1]['question_text'];?>:</label>
        <input type="text" name="q2" id="q2" value="<?=$data[0]['answer_2'];?>"  />
        </div>
        <div data-role="fieldcontain">
        <label for="q3"><?=$a_questions[2]['question_text'];?>:</label>
        <input type="text" name="q3" id="q3" value="<?=$data[0]['answer_3'];?>"  />
        </div>
		 


		 <div data-role="fieldcontain">
		 	
<label for="q4"><?=$a_questions[3]['question_text'];?>:</label>
		    <input type="text" name="q4" id="q4" style="max-width:50px;" value="<?=$data[0]['answer_4'];?>"  />
		    
		    
		</div>
		 
		 
		
		
		
		</div><!-- /content -->

		<div data-role="footer" data-id="foo1" data-position="fixed" style="height:30px; ">
			 
		</div><!-- /footer -->

		</div><!-- /page -->

		</body>
		</html>