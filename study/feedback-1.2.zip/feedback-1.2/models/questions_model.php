<?php
    require_once('../config.php'); 
   
    
    
	mysql_connect($host,$user,$pword);
	echo(mysql_error());
    //GET QUESTIONS
    $sql_questions = "SELECT * FROM ".$db.".questions";
    $res_questions = mysql_query($sql_questions);
    
    
    while($row_questions = mysql_fetch_assoc($res_questions)){
        $a_questions[] = $row_questions;
    }
    
    
    function get_questions(){
        /*
         require_once('../config.php'); 
        mysql_connect($host,$user,$pword);
        echo(mysql_error());
        //GET QUESTIONS
        $sql_questions = "SELECT * FROM ".$db.".questions";
        $res_questions = mysql_query($sql_questions);
        
        
        while($row_questions = mysql_fetch_assoc($res_questions)){
            $a_questions[] = $row_questions;
        }
        
        return $a_questions;
            */
    }
    
    function test(){
        return "fruitcake";
    }
    
?>
