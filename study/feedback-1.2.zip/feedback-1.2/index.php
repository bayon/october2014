<!DOCTYPE html> 
<?php include('config.php'); ?>

<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<title>Mobile Web Apps</title> 

	<link rel="stylesheet"  href="./css/themes/default/jquery.mobile-1.1.1.css" />  
 	<link rel="stylesheet" href="./css/themes/solo/solo.css"/>
	<script src="./js/jquery.js"></script>
 	<script src="./js/solo/solo.js"></script>
	<script src="./js/jquery.mobile-1.1.1.js"></script>

</head> 
<body> 
	<div data-role="page" class="type-index">

		<div data-role="header" data-theme="<?=$mainTheme;?>">
			<h1><?=$appName;?></h1>
			<a href="" data-icon="home" data-iconpos="notext" data-direction="reverse">Home</a>
			 
		</div><!-- /header -->
	
		<div data-role="content">
			<img src="core_keeper.png" alt="Core Keeper" width="120" height="120">
			<p>How are we doing?</p>
			<ul data-role="listview" data-inset="true">
				<li><a href="views/survey_view.php">Let us know:</a></li>
			</ul>

            <p>Admin</p>
            <ul data-role="listview" data-inset="true">
            <li><a href="views/admin_view.php">Admin:</a></li>
            </ul>	
		</div><!-- /content -->
		
	</div><!-- /page -->
</body>
</html>
