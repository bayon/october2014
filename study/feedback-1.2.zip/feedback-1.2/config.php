<?php
$host = "localhost";        
$user = "root";                     
$pword = "root";          
$db = "mobile2";              
$table = "simple_feedback"; 

$mainTheme = "e";
$appName = "Feedback-1.2";
$base_url = "http://localhost/feedback-1.2/";
?>