
<?php
    require_once('../config.php'); 
?>

<?php    
	mysql_connect($host,$user,$pword);
	echo(mysql_error());
    // STANDARD HTTP POST: 
	if($_POST['submit'] == "submit-value"){
        /*
        $sql ="INSERT INTO ".$db.".simple_feedback (answer_1 ,answer_2,answer_3,answer_4 )VALUES ( '".$_POST['question1'] ."',  '".$_POST['question2'] ."',  '".$_POST['question3'] ."',  '".$_POST['question4'] ."');";
        $res = mysql_query($sql);
         
        */
        $sql1 ="UPDATE ".$db.".questions SET question_text= '".$_POST['question1'] ."' WHERE question_id= 1 ;";
        $res1 = mysql_query($sql1);
        $sql2 ="UPDATE ".$db.".questions SET question_text= '".$_POST['question2'] ."' WHERE question_id= 2 ;";
        $res2 = mysql_query($sql2);
        $sql3 ="UPDATE ".$db.".questions SET question_text= '".$_POST['question3'] ."' WHERE question_id= 3 ;";
        $res3 = mysql_query($sql3);
        $sql4 ="UPDATE ".$db.".questions SET question_text= '".$_POST['question4'] ."' WHERE question_id= 4 ;";
        $res4 = mysql_query($sql4);
        
        
        
        
        
        //echo(mysql_error()); 
        
       
        //print_r($_POST); 
    }
       
?>
<script>
/*REDIRECT TO GRAPH: */

document.location = "<?=$base_url;?>";

</script>





