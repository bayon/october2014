
<?php
require_once('../config.php'); 
?>


<?php
	if(isset($_POST['id'])){
		
		mysql_connect($host,$user,$pword);
		echo(mysql_error());
	 	$sql = "SELECT * FROM ".$db.".".$table." WHERE id = '".$_POST['id']."'";
		$res = mysql_query($sql);
	 	while($row = mysql_fetch_assoc($res)){
	     	$data[] = $row;
		}
		
		include('../views/details/details_view.php'); 
	}else{
		
		
		//User Data
		mysql_connect($host,$user,$pword);
		echo(mysql_error());
	 	$sql = "SELECT * FROM ".$db.".".$table." ORDER BY 'id' ASC";
		$res = mysql_query($sql);
	 	while($row = mysql_fetch_assoc($res)){
	     	$data[] = $row;
		}
		
		//Slider Results
		  //CONTROLLER:
				//require_once('../config.php'); 
				//mysql_connect($host,$user,$pword);
				//echo(mysql_error());
				$sqlSlider = "SELECT answer_4 FROM ".$db.".simple_feedback ";
				$resSlider = mysql_query($sqlSlider);
			 	while($rowSlider = mysql_fetch_assoc($resSlider)){
			     	$a_data[] = $rowSlider;
				}
				//-----PREPARE DATA for json encode 
			   	$count = count($a_data);
				$i=0;
				while($i < $count){
					$dataset1[] =  "[".$i. ", ".(int)$a_data[$i]['answer_4']."]" ;
					$i++;
				}
				//JSON ENCODE
				$json_dataSet = json_encode($dataset1);
				//CREATE JSON ENCODED VARIABLE
				  echo("<script>var json_dataSet = '['+".$json_dataSet."+']';</script>"); 
					
		 
		
	}
?>


<?php    
	
?>

<?php
 //print_r( $_GET);
 // print_r( $_POST);
?>
 

 