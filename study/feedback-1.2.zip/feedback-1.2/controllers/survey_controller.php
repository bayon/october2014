
<?php
require_once('../config.php'); 
?>
	
<?php    
	mysql_connect($host,$user,$pword);
	echo(mysql_error());
 	 	// STANDARD HTTP POST: 
	if($_POST['submit'] == "submit-value"){
        $sql ="INSERT INTO ".$db.".simple_feedback (answer_1 ,answer_2,answer_3,answer_4 )VALUES ( '".$_POST['question1'] ."',  '".$_POST['question2'] ."',  '".$_POST['question3'] ."',  '".$_POST['question4'] ."');";
        $res = mysql_query($sql);
        if($res){
		 	?>
		 	<script>
			/*REDIRECT TO GRAPH:*/
				document.location = "<?=$base_url;?>views/graph_view.php";
			</script>
		 	<?php
		 }
 	} 
?>

 
 
