<?php
//Slider Results
				require_once('../config.php'); 
				mysql_connect($host,$user,$pword);
				echo(mysql_error());
				$sqlSlider = "SELECT answer_4 FROM ".$db.".simple_feedback ";
				$resSlider = mysql_query($sqlSlider);
			 	while($rowSlider = mysql_fetch_assoc($resSlider)){
			     	$a_data[] = $rowSlider;
				}
				//-----PREPARE DATA for json encode 
			   	$count = count($a_data);
				$i=0;
				while($i < $count){
					$dataset1[] =  "[".$i. ", ".(int)$a_data[$i]['answer_4']."]" ;
					$i++;
				}
				//JSON ENCODE
				$json_dataSet = json_encode($dataset1);
				//CREATE JSON ENCODED VARIABLE
				 echo("<script>var json_dataSet = '['+".$json_dataSet."+']';</script>"); 
				 
?>
<?php if($_POST['refresh'] == "refreshIt"){ ?>
 		<script>
			/*REDIRECT TO GRAPH:*/
				document.location = "<?=$base_url;?>views/graph_view.php";
			</script>
			
<?php } ?>