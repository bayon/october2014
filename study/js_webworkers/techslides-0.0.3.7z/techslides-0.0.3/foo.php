
<?php 

//controller
echo('{"ajax":"called on background thread"}'); 
?>

