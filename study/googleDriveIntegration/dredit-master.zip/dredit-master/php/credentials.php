<?php

// obtain these credentials from https://code.google.com/apis/console
const CLIENT_ID = '[[ YOUR CLIENT ID ]]';
const CLIENT_SECRET = '[[ YOUR CLIEND SECRET ]]';
const REDIRECT_URI = '[[ YOUR REDIRECT URI ]]';
