/* Copyright (c) 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//
//  GTLQueryDrive.m
//

// ----------------------------------------------------------------------------
// NOTE: This file is generated from Google APIs Discovery Service.
// Service:
//   Drive API (drive/v2)
// Description:
//   The API to interact with Drive.
// Documentation:
//   https://developers.google.com/drive/
// Classes:
//   GTLQueryDrive (34 custom class methods, 29 custom properties)

#import "GTLQueryDrive.h"

#import "GTLDriveAbout.h"
#import "GTLDriveApp.h"
#import "GTLDriveAppList.h"
#import "GTLDriveChange.h"
#import "GTLDriveChangeList.h"
#import "GTLDriveChildList.h"
#import "GTLDriveChildReference.h"
#import "GTLDriveFile.h"
#import "GTLDriveFileList.h"
#import "GTLDriveParentList.h"
#import "GTLDriveParentReference.h"
#import "GTLDrivePermission.h"
#import "GTLDrivePermissionList.h"
#import "GTLDriveRevision.h"
#import "GTLDriveRevisionList.h"

@implementation GTLQueryDrive

@dynamic appId, changeId, childId, convert, fields, fileId, folderId,
         includeDeleted, includeSubscribed, maxChangeIdCount, maxResults,
         newRevision, ocr, ocrLanguage, pageToken, parentId, permissionId,
         pinned, projection, q, revisionId, sendNotificationEmails,
         setModifiedDate, sourceLanguage, startChangeId, targetLanguage,
         timedTextLanguage, timedTextTrackName, updateViewedDate;

#pragma mark -
#pragma mark "about" methods
// These create a GTLQueryDrive object.

+ (id)queryForAboutGet {
  NSString *methodName = @"drive.about.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.expectedObjectClass = [GTLDriveAbout class];
  return query;
}

#pragma mark -
#pragma mark "apps" methods
// These create a GTLQueryDrive object.

+ (id)queryForAppsGetWithAppId:(NSString *)appId {
  NSString *methodName = @"drive.apps.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.appId = appId;
  query.expectedObjectClass = [GTLDriveApp class];
  return query;
}

+ (id)queryForAppsList {
  NSString *methodName = @"drive.apps.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.expectedObjectClass = [GTLDriveAppList class];
  return query;
}

#pragma mark -
#pragma mark "changes" methods
// These create a GTLQueryDrive object.

+ (id)queryForChangesGetWithChangeId:(NSString *)changeId {
  NSString *methodName = @"drive.changes.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.changeId = changeId;
  query.expectedObjectClass = [GTLDriveChange class];
  return query;
}

+ (id)queryForChangesList {
  NSString *methodName = @"drive.changes.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.expectedObjectClass = [GTLDriveChangeList class];
  return query;
}

#pragma mark -
#pragma mark "children" methods
// These create a GTLQueryDrive object.

+ (id)queryForChildrenDeleteWithFolderId:(NSString *)folderId
                                 childId:(NSString *)childId {
  NSString *methodName = @"drive.children.delete";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.folderId = folderId;
  query.childId = childId;
  return query;
}

+ (id)queryForChildrenGetWithFolderId:(NSString *)folderId
                              childId:(NSString *)childId {
  NSString *methodName = @"drive.children.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.folderId = folderId;
  query.childId = childId;
  query.expectedObjectClass = [GTLDriveChildReference class];
  return query;
}

+ (id)queryForChildrenInsertWithObject:(GTLDriveChildReference *)object
                              folderId:(NSString *)folderId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.children.insert";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.folderId = folderId;
  query.expectedObjectClass = [GTLDriveChildReference class];
  return query;
}

+ (id)queryForChildrenListWithFolderId:(NSString *)folderId {
  NSString *methodName = @"drive.children.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.folderId = folderId;
  query.expectedObjectClass = [GTLDriveChildList class];
  return query;
}

#pragma mark -
#pragma mark "files" methods
// These create a GTLQueryDrive object.

+ (id)queryForFilesCopyWithObject:(GTLDriveFile *)object
                           fileId:(NSString *)fileId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.files.copy";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesDeleteWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.files.delete";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  return query;
}

+ (id)queryForFilesGetWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.files.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesInsertWithObject:(GTLDriveFile *)object
                   uploadParameters:(GTLUploadParameters *)uploadParametersOrNil {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.files.insert";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.uploadParameters = uploadParametersOrNil;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesList {
  NSString *methodName = @"drive.files.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.expectedObjectClass = [GTLDriveFileList class];
  return query;
}

+ (id)queryForFilesPatchWithObject:(GTLDriveFile *)object
                            fileId:(NSString *)fileId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.files.patch";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesTouchWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.files.touch";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesTrashWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.files.trash";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesUntrashWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.files.untrash";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

+ (id)queryForFilesUpdateWithObject:(GTLDriveFile *)object
                             fileId:(NSString *)fileId
                   uploadParameters:(GTLUploadParameters *)uploadParametersOrNil {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.files.update";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.uploadParameters = uploadParametersOrNil;
  query.expectedObjectClass = [GTLDriveFile class];
  return query;
}

#pragma mark -
#pragma mark "parents" methods
// These create a GTLQueryDrive object.

+ (id)queryForParentsDeleteWithFileId:(NSString *)fileId
                             parentId:(NSString *)parentId {
  NSString *methodName = @"drive.parents.delete";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.parentId = parentId;
  return query;
}

+ (id)queryForParentsGetWithFileId:(NSString *)fileId
                          parentId:(NSString *)parentId {
  NSString *methodName = @"drive.parents.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.parentId = parentId;
  query.expectedObjectClass = [GTLDriveParentReference class];
  return query;
}

+ (id)queryForParentsInsertWithObject:(GTLDriveParentReference *)object
                               fileId:(NSString *)fileId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.parents.insert";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveParentReference class];
  return query;
}

+ (id)queryForParentsListWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.parents.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveParentList class];
  return query;
}

#pragma mark -
#pragma mark "permissions" methods
// These create a GTLQueryDrive object.

+ (id)queryForPermissionsDeleteWithFileId:(NSString *)fileId
                             permissionId:(NSString *)permissionId {
  NSString *methodName = @"drive.permissions.delete";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.permissionId = permissionId;
  return query;
}

+ (id)queryForPermissionsGetWithFileId:(NSString *)fileId
                          permissionId:(NSString *)permissionId {
  NSString *methodName = @"drive.permissions.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.permissionId = permissionId;
  query.expectedObjectClass = [GTLDrivePermission class];
  return query;
}

+ (id)queryForPermissionsInsertWithObject:(GTLDrivePermission *)object
                                   fileId:(NSString *)fileId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.permissions.insert";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDrivePermission class];
  return query;
}

+ (id)queryForPermissionsListWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.permissions.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDrivePermissionList class];
  return query;
}

+ (id)queryForPermissionsPatchWithObject:(GTLDrivePermission *)object
                                  fileId:(NSString *)fileId
                            permissionId:(NSString *)permissionId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.permissions.patch";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.permissionId = permissionId;
  query.expectedObjectClass = [GTLDrivePermission class];
  return query;
}

+ (id)queryForPermissionsUpdateWithObject:(GTLDrivePermission *)object
                                   fileId:(NSString *)fileId
                             permissionId:(NSString *)permissionId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.permissions.update";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.permissionId = permissionId;
  query.expectedObjectClass = [GTLDrivePermission class];
  return query;
}

#pragma mark -
#pragma mark "revisions" methods
// These create a GTLQueryDrive object.

+ (id)queryForRevisionsDeleteWithFileId:(NSString *)fileId
                             revisionId:(NSString *)revisionId {
  NSString *methodName = @"drive.revisions.delete";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.revisionId = revisionId;
  return query;
}

+ (id)queryForRevisionsGetWithFileId:(NSString *)fileId
                          revisionId:(NSString *)revisionId {
  NSString *methodName = @"drive.revisions.get";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.revisionId = revisionId;
  query.expectedObjectClass = [GTLDriveRevision class];
  return query;
}

+ (id)queryForRevisionsListWithFileId:(NSString *)fileId {
  NSString *methodName = @"drive.revisions.list";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.fileId = fileId;
  query.expectedObjectClass = [GTLDriveRevisionList class];
  return query;
}

+ (id)queryForRevisionsPatchWithObject:(GTLDriveRevision *)object
                                fileId:(NSString *)fileId
                            revisionId:(NSString *)revisionId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.revisions.patch";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.revisionId = revisionId;
  query.expectedObjectClass = [GTLDriveRevision class];
  return query;
}

+ (id)queryForRevisionsUpdateWithObject:(GTLDriveRevision *)object
                                 fileId:(NSString *)fileId
                             revisionId:(NSString *)revisionId {
  if (object == nil) {
    GTL_DEBUG_ASSERT(object != nil, @"%@ got a nil object", NSStringFromSelector(_cmd));
    return nil;
  }
  NSString *methodName = @"drive.revisions.update";
  GTLQueryDrive *query = [self queryWithMethodName:methodName];
  query.bodyObject = object;
  query.fileId = fileId;
  query.revisionId = revisionId;
  query.expectedObjectClass = [GTLDriveRevision class];
  return query;
}

@end
